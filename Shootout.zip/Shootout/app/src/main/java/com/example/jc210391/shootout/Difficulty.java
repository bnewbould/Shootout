package com.example.jc210391.shootout;

public enum Difficulty {
    EASY, NORMAL, HARD
}
