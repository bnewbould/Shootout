package com.example.jc210391.shootout;

public enum GameState {
    STANDOFF, FAKEOUT, SHOOTOUT, POSTSHOT
}
