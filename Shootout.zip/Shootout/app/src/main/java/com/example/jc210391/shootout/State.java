package com.example.jc210391.shootout;

public enum State {
    TITLE, GAME, SETTINGS, TUTORIAL, GAME_OVER
}
